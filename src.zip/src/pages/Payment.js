// src/pages/Payment.js
import React from "react";
import "./Payment.css";

function Payment() {
  return (
    <div className="payment-container">
      <h2 className="payment-heading">Bank Details</h2>

      {/* Domestic Donations */}
      <div className="payment-section">
        <h3 className="section-title">Domestic Donations:</h3>
        <p><strong>Name:</strong> Vidyadhanam & Annadhanam Trust</p>
        <p><strong>Bank:</strong> Canara Bank</p>
        <p><strong>Branch:</strong> St. Mary’s Road, Chennai 600018</p>
        <p><strong>A/c No.:</strong> 1287101014668</p>
        <p><strong>IFSC Code:</strong> CNRB0001287</p>
      </div>

      {/* QR Code */}
      <div className="qr-container">
        <img src="/qr.png" alt="QR Code" className="qr-code" />
      </div>

      {/* Overseas Donations */}
      <div className="payment-section">
        <h3 className="section-title">Overseas Donations (FCRA Approved Account):</h3>
        <p><strong>Name:</strong> Vidyadhanam & Annadhanam Trust</p>
        <p><strong>Bank:</strong> State Bank of India</p>
        <p><strong>Branch:</strong> New Delhi Main Branch, New Delhi 110001</p>
        <p><strong>A/c No.:</strong> 123456789012</p>
        <p><strong>SWIFT Code:</strong> SBININBB104</p>
      </div>
    </div>
  );
}

export default Payment;
