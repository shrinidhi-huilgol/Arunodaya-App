import React from "react";
import { FaMapMarkerAlt, FaPhoneAlt, FaEnvelope } from "react-icons/fa";
import "./ContactModal.css";

function ContactModal({ onClose }) {
  return (
    <div className="modalOverlay" onClick={onClose}>
      <div className="contactModalCard" onClick={(e) => e.stopPropagation()}>
        
        {/* Logo & Heading */}
        <div className="logoSection">
          <img
            src="/images/arunodaya-logo.png"
            alt="Arunodaya Logo"
            className="arunodayaLogo"
          />
          <h2 className="reachUs">Reach Us</h2>
        </div>

        {/* Close Button */}
        <div className="modalHeader">
          <button className="closeBtn" onClick={onClose}>
            ×
          </button>
        </div>

        {/* Contact Cards */}
        <div className="modalBody">
          <div className="contactCardGroup">
            
            {/* Office Card */}
            <div className="contactCard">
              <span className="contactIcon">
                <FaMapMarkerAlt />
              </span>
              <h3>Our Head Office</h3>
              <p>
                Kerala Rehabilitation Institute for the Physically Affected (KRIPA)
              </p>
              <p>
                Chunangamvely, Erumathala P.O.,<br />
                Aluva 683112 Kerala, India
              </p>
            </div>

            {/* Phone Card */}
            <div className="contactCard dark">
              <span className="contactIcon">
                <FaPhoneAlt />
              </span>
              <h3>Our Phone</h3>
              <p>9539839953</p>
              <p>9074241011</p>
              <p>0484-2838153</p>
            </div>

            {/* Mail Card */}
            <div className="contactCard">
              <span className="contactIcon">
                <FaEnvelope />
              </span>
              <h3>Our Mail</h3>
              <p>kriparajagiri@gmail.com</p>
              <p>kripaspecialschool@gmail.com</p>
              <p>kriparehab@gmail.com</p>
            </div>

          </div>
        </div>
      </div>
    </div>
  );
}

export default ContactModal;
